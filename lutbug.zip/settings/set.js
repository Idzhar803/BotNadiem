
global.owner = [
  "6281238037344", //ganti nomor owner
  "" //nomor owner kedua kalo ada
]
global.nomorbot = '6281238037344'
global.urlfoto = 'https://img101.pixhost.to/images/424/552981402_skyzopedia.jpg'

let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})